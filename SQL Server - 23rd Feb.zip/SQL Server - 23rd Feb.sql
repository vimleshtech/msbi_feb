
use sbi      -- change database 
			 -- select the comamnd and press F5 : to execute 

--create table : AccountType
create table AccountType
(acc_type_no int, name varchar(100))

--view data  , * : shwo all columns 
select * from  AccountType 

--insert data / save data
insert into AccountType(acc_type_no,name)
values(1,'Saving Account')

insert into AccountType(acc_type_no,name)
values(2,'Current Account')


--update data 
update  AccountType
set name ='Curr Account'
where acc_type_no = 2


--delete row
delete from AccountType where acc_type_no =2
 